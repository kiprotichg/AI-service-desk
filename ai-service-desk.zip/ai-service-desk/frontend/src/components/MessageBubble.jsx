export default function MessageBubble({ message }) {
  const { role, content, intent, sentiment } = message;
  return (
    <div className={`bubble ${role}`}>
      <p>{content}</p>
      {role === "user" && intent && (
        <div className="tags">
          <span className="tag">{intent}</span>
          <span className={`tag sentiment-${sentiment}`}>{sentiment}</span>
        </div>
      )}
    </div>
  );
}
