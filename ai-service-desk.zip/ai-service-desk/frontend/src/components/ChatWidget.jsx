import { useEffect, useRef, useState } from "react";
import { api } from "../api/client.js";
import MessageBubble from "./MessageBubble.jsx";

const SUGGESTIONS = [
  "How do I track my order?",
  "What is your refund policy?",
  "I want to talk to a human",
];

export default function ChatWidget() {
  const [name, setName] = useState("");
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [ticket, setTicket] = useState(null);
  const [error, setError] = useState("");
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  async function start(e) {
    e.preventDefault();
    setError("");
    try {
      const conv = await api.createConversation(name.trim() || "Guest");
      setConversation(conv);
      setMessages([{ id: "welcome", role: "assistant",
        content: `Hi ${conv.customer_name}! How can I help you today?` }]);
    } catch (err) {
      setError(err.message);
    }
  }

  async function send(text) {
    const content = text.trim();
    if (!content || sending) return;
    setInput("");
    setError("");
    setSending(true);
    const tempId = `pending-${Date.now()}`;
    setMessages((m) => [...m, { id: tempId, role: "user", content }]);
    try {
      const res = await api.sendMessage(conversation.id, conversation.token, content);
      setMessages((m) => [...m.filter((x) => x.id !== tempId), res.user_message, res.reply]);
      // The server's conversation object doesn't repeat the token, so keep ours.
      setConversation((c) => ({ ...res.conversation, token: c.token }));
      if (res.ticket) setTicket(res.ticket);
    } catch (err) {
      setMessages((m) => m.filter((x) => x.id !== tempId));
      setInput(content); // give the text back so the user can retry
      setError(err.message);
    } finally {
      setSending(false);
    }
  }

  async function endChat() {
    await api.closeConversation(conversation.id, conversation.token).catch(() => {});
    setConversation(null);
    setMessages([]);
    setTicket(null);
  }

  if (!conversation) {
    return (
      <form className="card start" onSubmit={start}>
        <h2>Chat with support</h2>
        <p className="muted">Our AI assistant answers instantly and hands off to a human when needed.</p>
        <label htmlFor="name">Your name</label>
        <input id="name" value={name} onChange={(e) => setName(e.target.value)}
          placeholder="Guest" maxLength={120} />
        <button type="submit" className="primary">Start chat</button>
        {error && <p className="error">{error}</p>}
      </form>
    );
  }

  return (
    <section className="card chat">
      <div className="chat-head">
        <div>
          <strong>Support chat</strong>
          <span className={`pill status-${conversation.status}`}>{conversation.status}</span>
        </div>
        <button className="ghost" onClick={endChat}>End chat</button>
      </div>

      {ticket && (
        <div className="banner">
          Ticket #{ticket.id} opened ({ticket.priority} priority) — a human agent will follow up.
        </div>
      )}

      <div className="messages" aria-live="polite">
        {messages.map((m) => <MessageBubble key={m.id} message={m} />)}
        {sending && <div className="bubble assistant typing">Typing…</div>}
        <div ref={endRef} />
      </div>

      {messages.length <= 1 && (
        <div className="suggestions">
          {SUGGESTIONS.map((s) => (
            <button key={s} className="chip" onClick={() => send(s)}>{s}</button>
          ))}
        </div>
      )}

      {error && <p className="error">{error}</p>}

      <form className="composer" onSubmit={(e) => { e.preventDefault(); send(input); }}>
        <input value={input} onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message…" maxLength={2000} disabled={sending}
          aria-label="Message" />
        <button type="submit" className="primary" disabled={sending || !input.trim()}>Send</button>
      </form>
    </section>
  );
}
