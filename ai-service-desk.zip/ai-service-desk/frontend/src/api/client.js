const BASE = import.meta.env.VITE_API_URL || "/api";
const AGENT_KEY = "agentSession";

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

// ---- agent session (sessionStorage: cleared when the tab closes) ----------
let onAgentLogout = () => {};

export const session = {
  get() {
    try { return JSON.parse(sessionStorage.getItem(AGENT_KEY)); } catch { return null; }
  },
  set(value) {
    try { sessionStorage.setItem(AGENT_KEY, JSON.stringify(value)); } catch { /* storage blocked */ }
  },
  clear() {
    try { sessionStorage.removeItem(AGENT_KEY); } catch { /* storage blocked */ }
  },
  onLogout(fn) { onAgentLogout = fn; },
};

async function request(path, { method = "GET", body, headers = {} } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error || `Request failed (${res.status})`, res.status);
  return data;
}

/** Request made as the logged-in agent; a 401 means the session expired. */
async function agentRequest(path, options = {}) {
  const token = session.get()?.token;
  try {
    return await request(path, {
      ...options, headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
  } catch (err) {
    if (err.status === 401) {
      session.clear();
      onAgentLogout();
    }
    throw err;
  }
}

const asCustomer = (token) => ({ "X-Conversation-Token": token });

export const api = {
  health: () => request("/health"),

  // customer
  createConversation: (customer_name) =>
    request("/conversations", { method: "POST", body: { customer_name } }),
  sendMessage: (id, token, content) =>
    request(`/conversations/${id}/messages`,
      { method: "POST", body: { content }, headers: asCustomer(token) }),
  closeConversation: (id, token) =>
    request(`/conversations/${id}/close`, { method: "POST", headers: asCustomer(token) }),

  // agent
  login: (username, password) =>
    request("/auth/login", { method: "POST", body: { username, password } }),
  listTickets: (status) => agentRequest(`/tickets${status ? `?status=${status}` : ""}`),
  updateTicket: (id, changes) =>
    agentRequest(`/tickets/${id}`, { method: "PATCH", body: changes }),
  analytics: () => agentRequest("/analytics"),
};
