import { useEffect, useState } from "react";
import { api, session } from "./api/client.js";
import ChatWidget from "./components/ChatWidget.jsx";
import TicketsPanel from "./components/TicketsPanel.jsx";
import AnalyticsPanel from "./components/AnalyticsPanel.jsx";
import LoginForm from "./components/LoginForm.jsx";

const TABS = [
  { id: "chat", label: "Customer chat" },
  { id: "tickets", label: "Tickets" },
  { id: "analytics", label: "Analytics" },
];

export default function App() {
  const [tab, setTab] = useState("chat");
  const [mode, setMode] = useState(null);
  const [agent, setAgent] = useState(() => session.get()?.agent ?? null);

  useEffect(() => {
    api.health().then((h) => setMode(h.ai_mode)).catch(() => setMode("down"));
    // If the token expires mid-session, any agent call drops us back to the login form.
    session.onLogout(() => setAgent(null));
  }, []);

  function handleLogin({ token, agent }) {
    session.set({ token, agent });
    setAgent(agent);
  }

  function logout() {
    session.clear();
    setAgent(null);
  }

  return (
    <div className="app">
      <header className="topbar">
        <h1>AI Service Desk</h1>
        <div className="row center">
          <span className={`mode mode-${mode}`}>
            {mode === null ? "Connecting…" : mode === "down" ? "Backend offline" :
              mode === "claude" ? "AI: Claude" : mode === "gemini" ? "AI: Gemini" :
              "AI: offline mode"}
          </span>
          {agent && (
            <span className="agent">
              {agent.username}
              <button className="ghost small" onClick={logout}>Sign out</button>
            </span>
          )}
        </div>
      </header>

      <nav className="tabs" role="tablist">
        {TABS.map((t) => (
          <button key={t.id} role="tab" aria-selected={tab === t.id}
            className={tab === t.id ? "active" : ""} onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </nav>

      <main>
        {/* Keep the chat mounted so switching tabs doesn't lose the conversation. */}
        <div hidden={tab !== "chat"}><ChatWidget /></div>
        {tab !== "chat" && !agent && <LoginForm onLogin={handleLogin} />}
        {tab === "tickets" && agent && <TicketsPanel />}
        {tab === "analytics" && agent && <AnalyticsPanel />}
      </main>
    </div>
  );
}
