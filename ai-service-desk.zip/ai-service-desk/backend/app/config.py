import os

# Which environment variables hold the key for each AI provider.
PROVIDER_KEYS = {
    "claude": ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN"),
    "gemini": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
}


class Config:
    # Signs auth tokens. If unset, create_app() generates a random one, so tokens
    # stop working whenever the server restarts - set it in .env.
    SECRET_KEY = os.getenv("SECRET_KEY")
    AGENT_TOKEN_MAX_AGE = 12 * 3600          # agents log in again after 12 hours
    CONVERSATION_TOKEN_MAX_AGE = 7 * 86400   # customer chat links last a week
    # Optional: create this agent on startup if it doesn't exist yet.
    AGENT_USERNAME = os.getenv("AGENT_USERNAME")
    AGENT_PASSWORD = os.getenv("AGENT_PASSWORD")
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "sqlite:///service.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
    # "claude" or "gemini". Each SDK reads its own key from the environment.
    AI_PROVIDER = os.getenv("AI_PROVIDER", "claude").strip().lower()
    # AI_MODEL is the older name for CLAUDE_MODEL and still works.
    CLAUDE_MODEL = os.getenv("CLAUDE_MODEL") or os.getenv("AI_MODEL") or "claude-opus-5-5"
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash-lite")
    # Only decides whether we try the live model or go straight to the offline
    # responder: true when the chosen provider's key is set.
    AI_ENABLED = any(os.getenv(k) for k in PROVIDER_KEYS.get(AI_PROVIDER, ()))
    MAX_HISTORY_MESSAGES = 20
    MAX_MESSAGE_LENGTH = 2000


class TestConfig(Config):
    TESTING = True
    SECRET_KEY = "test-secret"
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    AI_PROVIDER = "claude"
    AI_ENABLED = False
    AGENT_USERNAME = None
    AGENT_PASSWORD = None
