from .extensions import db
from .models import FAQ, Agent


def seed_agent(username, password):
    """Create the agent from AGENT_USERNAME / AGENT_PASSWORD if it's missing."""
    if not username or not password or Agent.query.filter_by(username=username).first():
        return
    agent = Agent(username=username)
    agent.set_password(password)
    db.session.add(agent)
    db.session.commit()

DEFAULT_FAQS = [
    ("How do I track my order?",
     "Go to Account > Orders and click 'Track' next to your order. You'll also get a "
     "tracking link by email once it ships.",
     "track,tracking,order,shipping,where,package"),
    ("How long does shipping take?",
     "Standard shipping takes 3-5 business days; express takes 1-2 business days.",
     "shipping,delivery,long,days,express,arrive"),
    ("What is your refund policy?",
     "You can return unused items within 30 days for a full refund. Refunds reach your "
     "card 5-7 business days after we receive the item.",
     "refund,return,money,back,policy"),
    ("How do I reset my password?",
     "Click 'Forgot password' on the sign-in page and follow the link we email you. "
     "The link expires after 1 hour.",
     "password,reset,forgot,login,sign"),
    ("Which payment methods do you accept?",
     "We accept Visa, Mastercard, American Express, PayPal and Apple Pay.",
     "payment,pay,card,paypal,methods,accept"),
    ("How do I change my delivery address?",
     "You can change the address in Account > Orders until the order ships. After that, "
     "contact support and we'll try to redirect it.",
     "address,change,delivery,update"),
]


def seed_faqs():
    if FAQ.query.first():
        return
    db.session.add_all(FAQ(question=q, answer=a, keywords=k) for q, a, k in DEFAULT_FAQS)
    db.session.commit()
