"""Token auth.

Two kinds of signed tokens (itsdangerous, keyed by SECRET_KEY):
  * agent tokens    - issued at login, sent as `Authorization: Bearer <token>`
  * customer tokens - issued when a chat starts, sent as `X-Conversation-Token`,
                      and only valid for that one conversation.
Different salts keep one kind from being accepted as the other.
"""
from functools import wraps

from flask import current_app, g, jsonify, request
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

from .extensions import db
from .models import Agent

AGENT_SALT = "agent-auth"
CUSTOMER_SALT = "conversation-access"


def _serializer(salt):
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt=salt)


def _load(token, salt, max_age):
    if not token:
        return None
    try:
        return _serializer(salt).loads(token, max_age=max_age)
    except (BadSignature, SignatureExpired):
        return None


def unauthorized(msg="Authentication required"):
    return jsonify({"error": msg}), 401


# ------------------------------------------------------------------ agents
def issue_agent_token(agent):
    return _serializer(AGENT_SALT).dumps({"agent_id": agent.id})


def current_agent():
    """Return the logged-in Agent for this request, or None."""
    if "agent" not in g:
        header = request.headers.get("Authorization", "")
        token = header[7:] if header.startswith("Bearer ") else None
        data = _load(token, AGENT_SALT, current_app.config["AGENT_TOKEN_MAX_AGE"])
        agent = db.session.get(Agent, data["agent_id"]) if data else None
        g.agent = agent if agent and agent.is_active else None
    return g.agent


def agent_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if current_agent() is None:
            return unauthorized()
        return view(*args, **kwargs)
    return wrapper


# --------------------------------------------------------------- customers
def issue_conversation_token(conversation):
    return _serializer(CUSTOMER_SALT).dumps({"conv_id": conversation.id})


def has_conversation_access(conv_id):
    data = _load(request.headers.get("X-Conversation-Token"), CUSTOMER_SALT,
                 current_app.config["CONVERSATION_TOKEN_MAX_AGE"])
    return bool(data) and data.get("conv_id") == conv_id
