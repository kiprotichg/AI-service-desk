import logging
import secrets

import click
from flask import Flask, jsonify
from flask_cors import CORS

from .config import PROVIDER_KEYS, Config
from .extensions import db

log = logging.getLogger(__name__)


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    if app.config["AI_PROVIDER"] not in PROVIDER_KEYS:
        raise ValueError(f"AI_PROVIDER must be one of {sorted(PROVIDER_KEYS)}, "
                         f"got {app.config['AI_PROVIDER']!r}")

    if not app.config.get("SECRET_KEY"):
        app.config["SECRET_KEY"] = secrets.token_hex(32)
        log.warning("SECRET_KEY is not set; using a random key. Logins and chat links "
                    "will stop working when the server restarts.")

    db.init_app(app)
    CORS(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}},
         allow_headers=["Content-Type", "Authorization", "X-Conversation-Token"])

    from .routes import analytics, auth, chat, faqs, tickets
    for module in (auth, chat, tickets, faqs, analytics):
        app.register_blueprint(module.bp)

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(405)
    def method_not_allowed(_):
        return jsonify({"error": "Method not allowed"}), 405

    @app.cli.command("create-agent")
    @click.argument("username")
    @click.password_option()
    def create_agent(username, password):
        """Create a support agent, or reset an existing agent's password."""
        from .models import Agent
        agent = Agent.query.filter_by(username=username).first() or Agent(username=username)
        agent.set_password(password)
        db.session.add(agent)
        db.session.commit()
        click.echo(f"Agent '{username}' saved.")

    with app.app_context():
        db.create_all()
        from .seed import seed_agent, seed_faqs
        seed_faqs()
        seed_agent(app.config["AGENT_USERNAME"], app.config["AGENT_PASSWORD"])

    return app
