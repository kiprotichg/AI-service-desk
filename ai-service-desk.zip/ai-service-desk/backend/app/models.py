from datetime import datetime, timezone

from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db


def utcnow():
    return datetime.now(timezone.utc)


class Agent(db.Model):
    """A support agent who can log in to manage tickets, FAQs and analytics."""
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {"id": self.id, "username": self.username}


class Conversation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(120), default="Guest")
    status = db.Column(db.String(20), default="open")  # open | escalated | closed
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow)
    messages = db.relationship(
        "Message", backref="conversation", order_by="Message.id", cascade="all, delete-orphan"
    )

    def to_dict(self, with_messages=False):
        data = {
            "id": self.id,
            "customer_name": self.customer_name,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
        }
        if with_messages:
            data["messages"] = [m.to_dict() for m in self.messages]
        return data


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey("conversation.id"), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # user | assistant
    content = db.Column(db.Text, nullable=False)
    intent = db.Column(db.String(40))
    sentiment = db.Column(db.String(20))
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "role": self.role,
            "content": self.content,
            "intent": self.intent,
            "sentiment": self.sentiment,
            "created_at": self.created_at.isoformat(),
        }


class Ticket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey("conversation.id"))
    subject = db.Column(db.String(200), nullable=False)
    summary = db.Column(db.Text)
    priority = db.Column(db.String(10), default="medium")  # low | medium | high
    status = db.Column(db.String(20), default="open")  # open | in_progress | resolved
    created_at = db.Column(db.DateTime(timezone=True), default=utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "conversation_id": self.conversation_id,
            "subject": self.subject,
            "summary": self.summary,
            "priority": self.priority,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
        }


class FAQ(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question = db.Column(db.String(300), nullable=False)
    answer = db.Column(db.Text, nullable=False)
    keywords = db.Column(db.String(300), default="")  # comma separated

    def to_dict(self):
        return {"id": self.id, "question": self.question, "answer": self.answer,
                "keywords": self.keywords}
