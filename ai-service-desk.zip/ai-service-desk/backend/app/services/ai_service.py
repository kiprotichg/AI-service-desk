"""AI reply generation.

The live model is either Claude or Gemini (AI_PROVIDER in .env). Both are asked
for the same JSON reply, so every answer also carries intent, sentiment and an
escalation decision. When no key is configured, or the live call fails for any
reason, a keyword responder answers instead so the chat keeps working.
"""
import json
import logging
import re
from dataclasses import dataclass

from flask import current_app

from . import knowledge_base

log = logging.getLogger(__name__)

INTENTS = ["billing", "technical", "account", "shipping", "refund", "general", "complaint"]
SENTIMENTS = ["positive", "neutral", "negative"]
MAX_OUTPUT_TOKENS = 2000

SYSTEM_PROMPT = """You are the customer-service assistant for an online store.
Answer the customer using the knowledge-base articles provided with each message.
If the articles don't cover the question, say so plainly and offer to hand the
conversation to a human agent - never invent policies, prices or order details.
Keep replies short (2-4 sentences), friendly and practical.

Set "escalate" to true when the customer asks for a human, is clearly upset,
reports something you cannot fix (damaged order, payment taken twice, account
locked), or the knowledge base does not answer the question."""

REPLY_SCHEMA = {
    "type": "object",
    "properties": {
        "reply": {"type": "string"},
        "intent": {"type": "string", "enum": INTENTS},
        "sentiment": {"type": "string", "enum": SENTIMENTS},
        "escalate": {"type": "boolean"},
        "ticket_subject": {"type": "string"},
    },
    "required": ["reply", "intent", "sentiment", "escalate", "ticket_subject"],
    "additionalProperties": False,
}

DECLINED_REPLY = "I'm not able to help with that here. Let me connect you with a human agent."


@dataclass
class AIReply:
    reply: str
    intent: str = "general"
    sentiment: str = "neutral"
    escalate: bool = False
    ticket_subject: str = ""
    source: str = "offline"  # "claude" | "gemini" | "offline"


def generate_reply(history, user_message):
    """history: list of {"role", "content"} dicts (oldest first), excluding user_message."""
    faqs = knowledge_base.search(user_message)
    cfg = current_app.config
    if cfg["AI_ENABLED"]:
        provider = cfg["AI_PROVIDER"]
        try:
            return _PROVIDERS[provider](history[-cfg["MAX_HISTORY_MESSAGES"]:],
                                        _user_turn(user_message, faqs))
        except Exception:
            # Deliberately broad: network errors, rate limits, bad keys and malformed
            # output differ per SDK, and every one of them should degrade to the
            # offline answer instead of failing the customer's message.
            log.exception("%s call failed, using offline responder", provider)
    return _offline_reply(user_message, faqs)


def _user_turn(user_message, faqs):
    # Knowledge-base context goes in the user turn (not the system prompt) so the
    # system prompt stays identical across requests and can be cached.
    return (f"<knowledge_base>\n{knowledge_base.as_context(faqs)}\n</knowledge_base>\n\n"
            f"<customer_message>\n{user_message}\n</customer_message>")


def _parse_reply(text, source):
    """Turn the model's JSON into an AIReply, guarding against off-schema values."""
    data = json.loads(text)
    reply = str(data.get("reply") or "").strip()
    if not reply:
        raise ValueError("model returned an empty reply")
    intent = data.get("intent")
    sentiment = data.get("sentiment")
    return AIReply(
        reply=reply,
        intent=intent if intent in INTENTS else "general",
        sentiment=sentiment if sentiment in SENTIMENTS else "neutral",
        escalate=bool(data.get("escalate")),
        ticket_subject=str(data.get("ticket_subject") or "")[:200],
        source=source,
    )


def _declined(source):
    return AIReply(reply=DECLINED_REPLY, escalate=True,
                   ticket_subject="Request needs human review", source=source)


# --------------------------------------------------------------------- Claude
_anthropic_client = None


def _get_anthropic_client():
    global _anthropic_client
    if _anthropic_client is None:
        import anthropic
        _anthropic_client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY
    return _anthropic_client


def _claude_reply(history, user_turn):
    response = _get_anthropic_client().beta.messages.create(
        model=current_app.config["CLAUDE_MODEL"],
        max_tokens=MAX_OUTPUT_TOKENS,
        system=SYSTEM_PROMPT,
        messages=[*history, {"role": "user", "content": user_turn}],
        output_config={
            "effort": "low",  # short chat replies; raise if quality needs it
            "format": {"type": "json_schema", "schema": REPLY_SCHEMA},
        },
        # On a safety decline, let the API retry on a fallback model automatically.
        betas=["server-side-fallback-2026-07-01"],
        fallbacks="default",
    )
    if response.stop_reason == "refusal":
        return _declined("claude")
    text = next(b.text for b in response.content if b.type == "text")
    return _parse_reply(text, "claude")


# --------------------------------------------------------------------- Gemini
_gemini_client = None


def _get_gemini_client():
    global _gemini_client
    if _gemini_client is None:
        from google import genai
        _gemini_client = genai.Client()  # reads GEMINI_API_KEY (or GOOGLE_API_KEY)
    return _gemini_client


def _gemini_reply(history, user_turn):
    from google.genai import types

    # Gemini calls the assistant role "model".
    contents = [
        {"role": "model" if m["role"] == "assistant" else "user", "parts": [{"text": m["content"]}]}
        for m in history
    ]
    contents.append({"role": "user", "parts": [{"text": user_turn}]})

    response = _get_gemini_client().models.generate_content(
        model=current_app.config["GEMINI_MODEL"],
        contents=contents,
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            max_output_tokens=MAX_OUTPUT_TOKENS,
            response_mime_type="application/json",
            response_json_schema=REPLY_SCHEMA,
        ),
    )
    # A safety block (or any other stop without output) comes back with no text.
    if not response.text:
        return _declined("gemini")
    return _parse_reply(response.text, "gemini")


_PROVIDERS = {"claude": _claude_reply, "gemini": _gemini_reply}


# ---------------------------------------------------------------- offline mode
_HUMAN = re.compile(r"\b(human|agent|person|representative|manager)\b", re.I)
_NEGATIVE = re.compile(r"\b(angry|terrible|awful|worst|broken|useless|furious|unacceptable|"
                       r"damaged|never arrived|scam)\b", re.I)
_POSITIVE = re.compile(r"\b(thanks|thank you|great|awesome|perfect|love)\b", re.I)
_INTENT_WORDS = {
    "refund": ["refund", "money back", "return"],
    "billing": ["bill", "charge", "charged", "invoice", "payment", "card"],
    "shipping": ["ship", "delivery", "deliver", "track", "arrive", "package", "order"],
    "account": ["account", "password", "login", "log in", "sign in", "email"],
    "technical": ["error", "bug", "crash", "not working", "app", "website"],
}


def _detect_intent(text):
    lower = text.lower()
    for intent, words in _INTENT_WORDS.items():
        if any(w in lower for w in words):
            return intent
    return "general"


def _offline_reply(user_message, faqs):
    sentiment = ("negative" if _NEGATIVE.search(user_message)
                 else "positive" if _POSITIVE.search(user_message) else "neutral")
    intent = "complaint" if sentiment == "negative" else _detect_intent(user_message)
    wants_human = bool(_HUMAN.search(user_message))

    if sentiment == "negative":
        # Keyword matching can't solve a complaint; a FAQ answer here reads as dismissive.
        reply = ("I'm sorry about this - that's not the experience we want for you. "
                 "I've opened a priority ticket and a support agent will contact you shortly.")
        escalate = True
    elif wants_human:
        reply = "Sure - I've created a ticket and a human agent will follow up shortly."
        escalate = True
    elif faqs:
        reply = faqs[0].answer
        escalate = False
    else:
        reply = ("I couldn't find an answer to that in our help articles. "
                 "I've passed your question to our support team.")
        escalate = True

    return AIReply(
        reply=reply,
        intent=intent,
        sentiment=sentiment,
        escalate=escalate,
        ticket_subject=user_message[:80],
        source="offline",
    )
