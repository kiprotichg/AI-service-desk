"""FAQ lookup used to ground the AI (and as the offline fallback)."""
import re

from ..models import FAQ

_WORD = re.compile(r"[a-z0-9']+")
_STOPWORDS = {"the", "a", "an", "is", "i", "my", "to", "do", "how", "can", "what", "of",
              "for", "and", "it", "in", "on", "me", "you", "your", "with", "are"}


def _tokens(text):
    return {w for w in _WORD.findall(text.lower()) if w not in _STOPWORDS}


def search(query, limit=3):
    """Return up to `limit` FAQs ranked by keyword overlap with the query."""
    q = _tokens(query)
    if not q:
        return []
    scored = []
    for faq in FAQ.query.all():
        kw = {k.strip().lower() for k in faq.keywords.split(",") if k.strip()}
        score = 2 * len(q & kw) + len(q & _tokens(faq.question))
        if score:
            scored.append((score, faq))
    scored.sort(key=lambda s: s[0], reverse=True)
    return [faq for _, faq in scored[:limit]]


def as_context(faqs):
    if not faqs:
        return "No matching knowledge-base articles."
    return "\n\n".join(f"Q: {f.question}\nA: {f.answer}" for f in faqs)
