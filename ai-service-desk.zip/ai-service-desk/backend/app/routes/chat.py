from flask import Blueprint, current_app, jsonify, request

from ..auth import (agent_required, current_agent, has_conversation_access,
                    issue_conversation_token, unauthorized)
from ..extensions import db
from ..models import Conversation, Message, Ticket
from ..services import ai_service

bp = Blueprint("chat", __name__, url_prefix="/api/conversations")


def _error(msg, code=400):
    return jsonify({"error": msg}), code


@bp.post("")
def create_conversation():
    """Public: anyone can start a chat. The returned token is the customer's key to it."""
    data = request.get_json(silent=True) or {}
    name = (data.get("customer_name") or "Guest").strip()[:120] or "Guest"
    conv = Conversation(customer_name=name)
    db.session.add(conv)
    db.session.commit()
    body = conv.to_dict(with_messages=True)
    body["token"] = issue_conversation_token(conv)
    return jsonify(body), 201


@bp.get("")
@agent_required
def list_conversations():
    convs = Conversation.query.order_by(Conversation.id.desc()).limit(100).all()
    return jsonify([c.to_dict() for c in convs])


@bp.get("/<int:conv_id>")
def get_conversation(conv_id):
    if not (has_conversation_access(conv_id) or current_agent()):
        return unauthorized()
    conv = db.get_or_404(Conversation, conv_id)
    return jsonify(conv.to_dict(with_messages=True))


@bp.post("/<int:conv_id>/messages")
def send_message(conv_id):
    # Only the customer who owns the chat can post as the customer.
    if not has_conversation_access(conv_id):
        return unauthorized()
    conv = db.get_or_404(Conversation, conv_id)
    if conv.status == "closed":
        return _error("Conversation is closed", 409)

    data = request.get_json(silent=True) or {}
    content = (data.get("content") or "").strip()
    if not content:
        return _error("Message content is required")
    if len(content) > current_app.config["MAX_MESSAGE_LENGTH"]:
        return _error("Message is too long")

    history = [{"role": m.role, "content": m.content} for m in conv.messages]
    ai = ai_service.generate_reply(history, content)

    user_msg = Message(conversation=conv, role="user", content=content,
                       intent=ai.intent, sentiment=ai.sentiment)
    bot_msg = Message(conversation=conv, role="assistant", content=ai.reply)
    db.session.add_all([user_msg, bot_msg])

    ticket = None
    if ai.escalate:
        ticket = Ticket.query.filter(Ticket.conversation_id == conv.id,
                                     Ticket.status != "resolved").first()
        if ticket is None:
            ticket = Ticket(
                conversation_id=conv.id,
                subject=(ai.ticket_subject or content)[:200],
                summary=content,
                priority="high" if ai.sentiment == "negative" else "medium",
            )
            db.session.add(ticket)
        conv.status = "escalated"

    db.session.commit()
    return jsonify({
        "user_message": user_msg.to_dict(),
        "reply": bot_msg.to_dict(),
        "source": ai.source,
        "conversation": conv.to_dict(),
        "ticket": ticket.to_dict() if ticket else None,
    }), 201


@bp.post("/<int:conv_id>/close")
def close_conversation(conv_id):
    if not (has_conversation_access(conv_id) or current_agent()):
        return unauthorized()
    conv = db.get_or_404(Conversation, conv_id)
    conv.status = "closed"
    db.session.commit()
    return jsonify(conv.to_dict())
