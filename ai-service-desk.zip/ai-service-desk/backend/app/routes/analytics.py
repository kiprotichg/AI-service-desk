from flask import Blueprint, current_app, jsonify
from sqlalchemy import func

from ..auth import agent_required
from ..extensions import db
from ..models import Conversation, Message, Ticket

bp = Blueprint("analytics", __name__, url_prefix="/api")


def _counts(column, *filters):
    rows = db.session.query(column, func.count()).filter(*filters).group_by(column).all()
    return {key or "unknown": n for key, n in rows}


@bp.get("/analytics")
@agent_required
def analytics():
    total_convs = db.session.query(func.count(Conversation.id)).scalar()
    escalated = db.session.query(func.count(Conversation.id)).filter(
        Conversation.status == "escalated").scalar()
    return jsonify({
        "conversations": total_convs,
        "messages": db.session.query(func.count(Message.id)).scalar(),
        "escalation_rate": round(escalated / total_convs, 3) if total_convs else 0,
        "intents": _counts(Message.intent, Message.role == "user"),
        "sentiment": _counts(Message.sentiment, Message.role == "user"),
        "tickets": _counts(Ticket.status),
    })


@bp.get("/health")
def health():
    cfg = current_app.config
    return jsonify({"status": "ok",
                    "ai_mode": cfg["AI_PROVIDER"] if cfg["AI_ENABLED"] else "offline"})
