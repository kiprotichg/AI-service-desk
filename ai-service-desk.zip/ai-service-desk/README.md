# AI Service Desk — AI for Service module (chat support)

An AI customer-service chat module: customers chat with an assistant that answers
from a FAQ knowledge base, tags each message with **intent** and **sentiment**, and
**escalates to a human ticket** when it can't help. Agents manage tickets and see analytics.

- **Backend:** Python, Flask, Flask-SQLAlchemy (SQLite), Claude or Gemini API
- **Frontend:** React 18 + Vite

## Project structure

```
backend/
  run.py                    # entry point (loads .env, starts Flask on :5000)
  requirements.txt
  .env.example
  app/
    __init__.py             # create_app() factory: config, DB, CORS, blueprints, seeding
    config.py               # Config / TestConfig
    extensions.py           # SQLAlchemy instance
    auth.py                 # signed agent + customer tokens, @agent_required
    models.py               # Agent, Conversation, Message, Ticket, FAQ
    seed.py                 # default FAQ articles + optional first agent
    routes/
      auth.py               # /api/auth/login, /api/auth/me
      chat.py               # /api/conversations ...
      tickets.py            # /api/tickets ...
      faqs.py               # /api/faqs ...
      analytics.py          # /api/analytics, /api/health
    services/
      ai_service.py         # Claude / Gemini calls (structured JSON) + offline fallback
      knowledge_base.py     # keyword FAQ search used to ground replies
  tests/
    test_api.py             # API, validation and auth tests
    test_ai_providers.py    # Claude + Gemini paths with faked SDK clients
frontend/
  vite.config.js            # proxies /api -> Flask in dev
  src/
    App.jsx                 # tabs: Customer chat / Tickets / Analytics
    api/client.js           # fetch wrapper; attaches agent / chat tokens
    components/
      LoginForm.jsx         # agent sign-in (guards Tickets + Analytics)
      ChatWidget.jsx        # start chat, send messages, escalation banner
      MessageBubble.jsx
      TicketsPanel.jsx      # filter + change status/priority
      AnalyticsPanel.jsx    # stat cards + bar charts
    styles.css              # light/dark theme
```

## Running it

Backend (terminal 1):

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate          # macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env          # set AI_PROVIDER + its key, SECRET_KEY, AGENT_PASSWORD
python run.py
```

The agent account in `AGENT_USERNAME` / `AGENT_PASSWORD` is created on first start.
To add more agents, or reset a password:

```bash
flask --app run create-agent alice
```

Frontend (terminal 2):

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. The header shows which AI is answering. With no key for the
chosen provider, the bot runs in **offline mode** (keyword matching).

Tests: `cd backend && python -m pytest -q`

> Windows tip: if `pip install` fails with *"filename or extension is too long"*, move the
> project to a short path such as `C:\dev\ai-service` or enable Windows long paths.

## API

**Access:** *public*; *agent* = `Authorization: Bearer <token>` from login;
*customer* = `X-Conversation-Token` returned when that chat was started.

| Method | Path | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | public | Status + AI mode (`claude` / `gemini` / `offline`) |
| POST | `/api/auth/login` | public | `{username, password}` → `{token, agent}` |
| GET | `/api/auth/me` | agent | Current agent |
| POST | `/api/conversations` | public | Start a chat `{customer_name}` → includes `token` |
| GET | `/api/conversations` | agent | List chats |
| GET | `/api/conversations/<id>` | customer or agent | Chat with messages |
| POST | `/api/conversations/<id>/messages` | customer | Send `{content}` → AI reply, tags, optional ticket |
| POST | `/api/conversations/<id>/close` | customer or agent | Close a chat |
| GET | `/api/tickets?status=` | agent | List tickets |
| PATCH | `/api/tickets/<id>` | agent | Update `{status, priority}` |
| GET | `/api/faqs` | public | List the knowledge base |
| POST/DELETE | `/api/faqs[/<id>]` | agent | Edit the knowledge base |
| GET | `/api/analytics` | agent | Counts, intents, sentiment, escalation rate |

## How auth works

- **Agents** sign in with a username and password. Passwords are stored as salted
  hashes (Werkzeug's scrypt hashing). Login returns a signed token that expires after
  12 hours. The frontend keeps it in `sessionStorage`, so closing the tab signs you out,
  and any 401 response sends you back to the login form.
- **Customers** don't need accounts. Starting a chat returns a token signed for *that
  one conversation*, so a customer can't read or post to anyone else's chat.
- The two kinds of token use different signing salts, so a customer token can't be
  used as an agent token. An agent can read any chat but can't post as the customer.
- Login gives the same error, with similar timing, for an unknown user and for a wrong
  password, so usernames can't be probed.
- Deactivating an agent (`is_active = False`) locks them out immediately, even with a
  token that hasn't expired.

## Choosing the AI provider

Set `AI_PROVIDER` in `backend/.env`, then restart the backend:

| Provider | `AI_PROVIDER` | Key | Model setting (default) |
|---|---|---|---|
| Claude | `claude` | `ANTHROPIC_API_KEY` | `CLAUDE_MODEL` (`claude-opus-5-5`) |
| Gemini | `gemini` | `GEMINI_API_KEY` | `GEMINI_MODEL` (`gemini-3.5-flash-lite`) |

Both providers get the same instructions, knowledge-base articles and JSON reply
format, so nothing else in the app changes. You can keep both keys in `.env` and
switch with one line.

## How the AI works

1. `knowledge_base.search()` finds the top 3 FAQ articles for the message.
2. `ai_service` sends the conversation history plus those articles to the chosen
   provider with a **JSON-schema output** (Claude: `output_config.format`; Gemini:
   `response_json_schema`), so every reply comes back as
   `{reply, intent, sentiment, escalate, ticket_subject}`. Values outside the allowed
   intents or sentiments are reset to `general` / `neutral`.
3. If `escalate` is true, the conversation is marked escalated and one ticket is opened
   (high priority when the sentiment is negative). Later messages reuse that ticket, so
   there are no duplicates.
4. If the model declines (a Claude refusal, or a Gemini safety block with no text), the
   customer is told a human will help and a ticket is opened. If the API is down, the key
   is wrong, or the output isn't valid JSON, the offline responder answers instead, so the
   chat never breaks.

---

## Code review

### What's solid
- **Clear layering:** routes handle HTTP and validation only. The AI and search logic
  live in `services/`, and the models stay thin. Swapping SQLite for Postgres means
  changing `DATABASE_URL`.
- **App factory + TestConfig:** tests run against an in-memory DB with the AI turned off,
  so they're fast and free.
- **Structured AI output:** the JSON schema with enums guarantees valid intent and
  sentiment values for analytics.
- **Graceful degradation:** API errors, refusals and bad output all fall back to the
  offline responder.
- **Input validation:** empty or over-long messages are rejected with 400, closed chats
  with 409, and bad ticket status or priority values with 400. JSON 404/405 handlers
  replace HTML error pages.
- **Cache-friendly prompt:** the system prompt is static, and the per-request FAQ
  context goes in the user turn.
- **Frontend:** optimistic message send with rollback on error (the text goes back in
  the box), chat state kept across tab switches, accessible labels, dark mode, and a
  layout that works on mobile.

### Bug found and fixed during testing
- In offline mode, an angry complaint ("my package arrived damaged…") matched the
  *order-tracking* FAQ, so the reply was a canned tracking answer. Negative sentiment
  now always gets an apology plus escalation, and there's a test for it.

### Authentication (added)
- Agent login protects tickets, analytics, the chat list and FAQ editing. Customer
  chats are locked to their own conversation token. 12 auth tests cover login, a
  401 on every protected endpoint, cross-chat access, token swapping, deactivated
  agents and the `create-agent` command.

### Gemini support (added)
- `AI_PROVIDER` picks Claude or Gemini, and the rest of the app doesn't change. An
  unknown provider name stops the app at startup with a clear error. 11 provider tests
  fake each SDK and check the request (model, schema, history roles), the reply
  parsing, decline handling and the offline fallback.
- **Not yet tried with a real Gemini key.** A request sent with a fake key reached
  Google and was rejected only for the key. Google checks the key first, so this
  doesn't prove Gemini accepts the reply schema. Send one chat message with your
  key to confirm. If it fails, the backend log shows Google's error and customers
  get the offline answer meanwhile.

### Issues to address before production
1. **No rate limiting, on login or chat.** Passwords can be guessed without limit, and
   each chat message is a paid AI call. Add Flask-Limiter: about 5 login attempts
   per minute per IP, and a per-conversation message limit.
2. **Tokens can't be revoked one at a time.** They're signed, not stored. To cut off an
   agent, deactivate the account. To cut off everyone, change `SECRET_KEY`. Add a
   token table if you need per-device sign-out.
3. **Customers lose their chat on page reload.** The chat token is only held in
   memory. Save it in `sessionStorage` if customers should be able to resume.
4. **HTTPS required in production.** Bearer tokens sent over plain HTTP can be
   intercepted. Also note that `sessionStorage` can be read by any script running on
   the page, so keep the frontend free of untrusted scripts.
5. **Blocking AI call.** The request waits for the model to finish. That's fine for short
   replies, but for long ones switch to streaming (SSE) so text appears as it's written.
6. **No migrations.** `db.create_all()` won't change existing tables. Add Flask-Migrate
   (Alembic) once the schema starts changing.
7. **Dev server.** `run.py` uses Flask's debug server. Deploy with gunicorn or waitress,
   and set `debug=False`.
8. **Basic knowledge-base search.** Keyword overlap misses synonyms. For a larger FAQ,
   use full-text search (SQLite FTS5 or Postgres `tsvector`) or embeddings.
9. **Offline mode is a fallback, not a product.** Its intent and sentiment detection is
   regex-based and will misclassify sometimes.
10. **Broad fallback catch.** `generate_reply` catches every exception from the provider
    call, so a coding bug there also falls back silently. It's logged with a full
    traceback, so check the backend log if replies are always offline.
